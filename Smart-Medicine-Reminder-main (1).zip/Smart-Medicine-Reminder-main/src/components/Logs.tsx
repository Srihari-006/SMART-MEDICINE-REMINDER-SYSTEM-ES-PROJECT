import React from 'react';
import { Log, Medicine, Patient } from '../types';
import { Download, FileText, CheckCircle2, AlertCircle, Clock } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { cn } from '../lib/utils';
import { isSameDay, startOfDay, subDays, format } from 'date-fns';

export default function Logs({ logs, medicines, patient }: { logs: Log[], medicines: Medicine[], patient: Patient | null }) {
  const patientName = patient?.name || 'Patient';

  // Helper to get medicines for a slot
  const getMedicinesForSlot = (slot: string) => {
    return medicines.filter(m => m.slot === slot);
  };

  // Calculate missed doses for the last 7 days and enrich with medicine details
  const allLogs = (() => {
    const combined: (Log & { details?: string })[] = logs.map(l => {
      const inst = l.instruction || 'after';
      const meds = medicines.filter(m => m.slot === l.slot && m.food_instruction === inst);
      const details = meds.map(m => `${m.name} (${m.dosage})`).join(', ') || 'Unknown Medicine';
      return { ...l, details };
    });

    const today = startOfDay(new Date());
    
    // Check last 7 days for missed doses
    for (let i = 0; i < 7; i++) {
      const day = subDays(today, i);
      const dayLogs = logs.filter(l => isSameDay(new Date(l.timestamp), day));
      
      const slots = ['breakfast', 'lunch', 'dinner'];
      slots.forEach(slot => {
        const meds = getMedicinesForSlot(slot);
        if (meds.length === 0) return;

        const instructions = ['before', 'after'] as const;
        instructions.forEach(inst => {
          const medsForInst = meds.filter(m => m.food_instruction === inst);
          if (medsForInst.length === 0) return;

          const isTaken = dayLogs.some(l => l.slot === slot && (l.instruction || 'after') === inst && l.status === 'taken');
          if (isTaken) return;

          // If not taken, check if it's missed
          let isMissed = false;
          if (isSameDay(day, today)) {
            const now = new Date();
            const currentMinutes = now.getHours() * 60 + now.getMinutes();
            
            const times = medsForInst.map(m => {
              if (!m.calculatedTime) return 0;
              const normalized = m.calculatedTime.replace(/\s+/g, ' ').trim();
              const [timePart, period] = normalized.split(' ');
              const [hours, minutes] = timePart.split(':').map(Number);
              let totalMinutes = hours * 60 + minutes;
              if (period) {
                if (period.toUpperCase() === 'PM' && hours !== 12) totalMinutes += 12 * 60;
                if (period.toUpperCase() === 'AM' && hours === 12) totalMinutes -= 12 * 60;
              }
              return totalMinutes;
            });
            
            const latestTime = Math.max(...times);
            if (currentMinutes > (latestTime + 1)) {
              isMissed = true;
            }
          } else {
            isMissed = true;
          }

          if (isMissed) {
            const alreadyLogged = dayLogs.some(l => l.slot === slot && (l.instruction || 'after') === inst && l.status === 'missed');
            if (!alreadyLogged) {
              const details = medsForInst.map(m => `${m.name} (${m.dosage})`).join(', ');
              combined.push({
                id: `missed-${day.getTime()}-${slot}-${inst}`,
                slot,
                instruction: inst,
                status: 'missed',
                timestamp: day.toISOString(),
                caregiverUid: '',
                details
              });
            }
          }
        });
      });
    }

    return combined.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  })();

  // Group logs by date for the UI table
  const groupedLogs = (() => {
    const groups: { [key: string]: { [key: string]: { [key: string]: { status: string, details: string } } } } = {};
    
    allLogs.forEach(log => {
      const dateKey = format(new Date(log.timestamp), 'MMM dd, yyyy');
      if (!groups[dateKey]) {
        groups[dateKey] = { 
          breakfast: { before: { status: '-', details: '' }, after: { status: '-', details: '' } },
          lunch: { before: { status: '-', details: '' }, after: { status: '-', details: '' } },
          dinner: { before: { status: '-', details: '' }, after: { status: '-', details: '' } }
        };
      }
      
      const instruction = log.instruction || 'after'; // Default to after if not specified
      if (groups[dateKey][log.slot]) {
        groups[dateKey][log.slot][instruction] = { 
          status: log.status, 
          details: log.details || '' 
        };
      }
    });

    return Object.entries(groups).sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime());
  })();

  const exportPDF = () => {
    try {
      const doc = new jsPDF();
      
      // Header
      doc.setFontSize(22);
      doc.setTextColor(30, 41, 59);
      doc.text('Smart Medicine Intake Report', 14, 22);
      
      // Patient Info Section
      doc.setFontSize(12);
      doc.setTextColor(100);
      doc.text('PATIENT INFORMATION', 14, 35);
      doc.setDrawColor(226, 232, 240);
      doc.line(14, 37, 196, 37);

      doc.setFontSize(10);
      doc.setTextColor(71, 85, 105);
      doc.text(`Name: ${patientName}`, 14, 45);
      doc.text(`Age: ${patient?.age || 'N/A'} years`, 14, 52);
      doc.text(`Conditions: ${patient?.medicalConditions || 'None listed'}`, 14, 59);
      
      doc.text(`Report Generated: ${new Date().toLocaleString()}`, 130, 45);

      // Group logs by date for the main table
      const groupedByDate: { [key: string]: { [key: string]: { before: string, after: string } } } = {};
      
      allLogs.forEach(log => {
        const dateKey = format(new Date(log.timestamp), 'MMM dd, yyyy');
        if (!groupedByDate[dateKey]) {
          groupedByDate[dateKey] = { 
            breakfast: { before: '-', after: '-' }, 
            lunch: { before: '-', after: '-' }, 
            dinner: { before: '-', after: '-' } 
          };
        }
        
        const meds = getMedicinesForSlot(log.slot);
        const inst = log.instruction || 'after';
        const medsForInst = meds.filter(m => m.food_instruction === inst);
        const medList = medsForInst.map(m => m.name).join(', ');
        const statusText = log.status === 'taken' ? 'TAKEN' : 'MISSED';
        
        if (groupedByDate[dateKey][log.slot]) {
          groupedByDate[dateKey][log.slot][inst] = `${statusText}\n(${medList})`;
        }
      });

      const tableData = Object.entries(groupedByDate)
        .sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime())
        .map(([date, slots]) => [
          date,
          slots.breakfast.before,
          slots.breakfast.after,
          slots.lunch.before,
          slots.lunch.after,
          slots.dinner.before,
          slots.dinner.after
        ]);

      autoTable(doc, {
        startY: 75,
        head: [['Date', 'Breakfast (Before)', 'Breakfast (After)', 'Lunch (Before)', 'Lunch (After)', 'Dinner (Before)', 'Dinner (After)']],
        body: tableData,
        headStyles: { 
          fillColor: [37, 99, 235], 
          fontSize: 8, 
          halign: 'center',
          fontStyle: 'bold'
        },
        bodyStyles: { 
          fontSize: 7, 
          halign: 'center',
          textColor: [51, 65, 85],
          cellPadding: 2
        },
        alternateRowStyles: { fillColor: [248, 250, 252] },
        columnStyles: {
          0: { cellWidth: 25 },
          1: { cellWidth: 28 },
          2: { cellWidth: 28 },
          3: { cellWidth: 28 },
          4: { cellWidth: 28 },
          5: { cellWidth: 28 },
          6: { cellWidth: 28 }
        }
      });

      // Medicine Summary Table
      const summaryData: { [key: string]: { total: number, taken: number, dosage: string, name: string } } = {};
      
      // Initialize summary with all medicines
      medicines.forEach(m => {
        const key = `${m.name}-${m.dosage}`;
        summaryData[key] = { total: 0, taken: 0, dosage: m.dosage, name: m.name };
      });

      // Calculate totals from allLogs
      allLogs.forEach(log => {
        const inst = log.instruction || 'after';
        const meds = medicines.filter(m => m.slot === log.slot && m.food_instruction === inst);
        meds.forEach(m => {
          const key = `${m.name}-${m.dosage}`;
          if (summaryData[key]) {
            summaryData[key].total += 1;
            if (log.status === 'taken') {
              summaryData[key].taken += 1;
            }
          }
        });
      });

      const summaryTableRows = Object.values(summaryData).map(data => [
        data.name,
        data.dosage,
        data.total.toString(),
        data.taken.toString(),
        `${data.total > 0 ? Math.round((data.taken / data.total) * 100) : 0}%`
      ]);

      doc.addPage();
      doc.setFontSize(16);
      doc.setTextColor(30, 41, 59);
      doc.text('Medicine Adherence Summary', 14, 22);
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text('Overview of total scheduled vs. taken doses for each medication.', 14, 30);

      autoTable(doc, {
        startY: 40,
        head: [['Medicine Name', 'Dosage', 'Total Scheduled', 'Total Taken', 'Adherence %']],
        body: summaryTableRows,
        headStyles: { fillColor: [15, 23, 42], fontSize: 10, halign: 'center' },
        bodyStyles: { fontSize: 9, halign: 'center' },
        alternateRowStyles: { fillColor: [248, 250, 252] }
      });

      doc.save(`medicine-report-${patientName}-${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (error) {
      console.error('PDF Export Error:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <FileText className="w-6 h-6 text-blue-600" />
          Recent Activity Logs
        </h3>
        <button 
          onClick={exportPDF}
          disabled={allLogs.length === 0}
          className="flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl font-bold shadow-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download className="w-5 h-5" />
          Export PDF
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th rowSpan={2} className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-r border-slate-200">Date</th>
                <th colSpan={2} className="px-6 py-2 text-xs font-bold text-slate-500 uppercase tracking-wider text-center border-r border-slate-200">Breakfast</th>
                <th colSpan={2} className="px-6 py-2 text-xs font-bold text-slate-500 uppercase tracking-wider text-center border-r border-slate-200">Lunch</th>
                <th colSpan={2} className="px-6 py-2 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Dinner</th>
              </tr>
              <tr className="bg-slate-50/50 border-b border-slate-200">
                <th className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase text-center border-r border-slate-100">Before</th>
                <th className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase text-center border-r border-slate-200">After</th>
                <th className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase text-center border-r border-slate-100">Before</th>
                <th className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase text-center border-r border-slate-200">After</th>
                <th className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase text-center border-r border-slate-100">Before</th>
                <th className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase text-center">After</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {groupedLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    No activity logs recorded yet.
                  </td>
                </tr>
              ) : (
                groupedLogs.map(([date, slots]) => (
                  <tr key={date} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 border-r border-slate-100">
                      <p className="text-sm font-bold text-slate-900">{date}</p>
                    </td>
                    {['breakfast', 'lunch', 'dinner'].map(slot => (
                      <React.Fragment key={slot}>
                        {['before', 'after'].map(inst => {
                          const data = slots[slot][inst];
                          const isLastInst = inst === 'after';
                          return (
                            <td key={`${slot}-${inst}`} className={cn(
                              "px-4 py-4 text-center",
                              isLastInst && slot !== 'dinner' ? "border-r border-slate-200" : "border-r border-slate-100"
                            )}>
                              {data.status === '-' ? (
                                <span className="text-slate-200">-</span>
                              ) : (
                                <div className="flex flex-col items-center gap-1">
                                  <div className={cn(
                                    "flex items-center gap-1 font-bold text-[10px]",
                                    data.status === 'taken' ? "text-emerald-600" : "text-rose-600"
                                  )}>
                                    {data.status === 'taken' ? <CheckCircle2 className="w-2.5 h-2.5" /> : <AlertCircle className="w-2.5 h-2.5" />}
                                    {data.status.toUpperCase()}
                                  </div>
                                  {data.details && (
                                    <p className="text-[9px] text-slate-400 leading-tight max-w-[80px]">
                                      {data.details}
                                    </p>
                                  )}
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </React.Fragment>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
