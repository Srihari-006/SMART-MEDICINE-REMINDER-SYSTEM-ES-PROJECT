import React, { useState, useEffect } from 'react';
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { motion } from 'motion/react';
import { Pill, Clock, Info, X, AlertCircle, Loader2 } from 'lucide-react';
import { calculateMedicineTime } from '../lib/utils';
import { MealTimes, Medicine } from '../types';

export default function MedicineForm({ onClose, mealTimes, caregiverUid, editingMedicine }: { 
  onClose: () => void, 
  mealTimes: MealTimes | null, 
  caregiverUid: string,
  editingMedicine?: Medicine | null
}) {
  const [formData, setFormData] = useState<Partial<Medicine>>({
    name: '',
    dosage: '',
    slot: 'breakfast',
    food_instruction: 'before',
    notes: '',
    caregiverUid
  });

  useEffect(() => {
    if (editingMedicine) {
      setFormData({
        name: editingMedicine.name,
        dosage: editingMedicine.dosage,
        slot: editingMedicine.slot,
        food_instruction: editingMedicine.food_instruction,
        notes: editingMedicine.notes || '',
        caregiverUid: editingMedicine.caregiverUid
      });
    }
  }, [editingMedicine]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const fallbackTimes = {
        breakfast: '08:00',
        lunch: '13:00',
        dinner: '20:00'
      };

      const mealTime = mealTimes?.[formData.slot as keyof MealTimes] as string || fallbackTimes[formData.slot as keyof typeof fallbackTimes];
      const hasMealTime = !!mealTimes?.[formData.slot as keyof MealTimes];
      
      const calculatedTime = calculateMedicineTime(mealTime, formData.food_instruction!);

      if (editingMedicine?.id) {
        await updateDoc(doc(db, 'medicines', editingMedicine.id), {
          ...formData,
          calculatedTime,
          status: hasMealTime ? 'active' : 'pending',
          updatedAt: new Date().toISOString()
        });
      } else {
        await addDoc(collection(db, 'medicines'), {
          ...formData,
          calculatedTime,
          status: hasMealTime ? 'active' : 'pending',
          createdAt: new Date().toISOString()
        });
      }
      onClose();
    } catch (err: any) {
      console.error('Error saving medicine:', err);
      setError(err.message || 'Failed to save medicine. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden"
      >
        <div className="p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold">{editingMedicine ? 'Edit Medicine' : 'Add New Medicine'}</h3>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-all">
              <X className="w-6 h-6 text-slate-400" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Medicine Name</label>
              <div className="relative">
                <Pill className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Paracetamol"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Dosage</label>
              <input 
                type="text" 
                value={formData.dosage}
                onChange={e => setFormData({...formData, dosage: e.target.value})}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., 500mg"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Time Slot</label>
                <select 
                  value={formData.slot}
                  onChange={e => setFormData({...formData, slot: e.target.value as any})}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="breakfast">Breakfast</option>
                  <option value="lunch">Lunch</option>
                  <option value="dinner">Dinner</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Food Instruction</label>
                <select 
                  value={formData.food_instruction}
                  onChange={e => setFormData({...formData, food_instruction: e.target.value as any})}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="before">Before Food</option>
                  <option value="after">After Food</option>
                </select>
              </div>
            </div>

            {(!mealTimes || !mealTimes[formData.slot as keyof MealTimes]) && (
              <div className="flex items-center gap-2 p-3 bg-amber-50 text-amber-700 rounded-xl text-sm border border-amber-100">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <p>⚠ Meal time not set. Please configure meal time to activate schedule.</p>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Notes (Optional)</label>
              <div className="relative">
                <Info className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <textarea 
                  value={formData.notes}
                  onChange={e => setFormData({...formData, notes: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 h-24 resize-none"
                  placeholder="Any special instructions..."
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 text-red-600 rounded-xl text-sm border border-red-100">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <p>{error}</p>
              </div>
            )}

            <div className="flex gap-3 pt-4">
              <button 
                type="button"
                onClick={onClose}
                disabled={loading}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-all disabled:opacity-50"
              >
                Cancel
              </button>
              <button 
                type="submit"
                disabled={loading}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-100 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (editingMedicine ? 'Save Changes' : 'Add Medicine')}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
