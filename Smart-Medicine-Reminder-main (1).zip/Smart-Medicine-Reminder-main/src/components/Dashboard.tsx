import React, { useState, useEffect } from 'react';
import { User, signOut } from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  getDoc,
  setDoc,
  addDoc,
  deleteDoc,
  updateDoc,
  orderBy,
  limit
} from 'firebase/firestore';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addMonths, 
  subMonths,
  isToday,
  isAfter,
  startOfDay
} from 'date-fns';
import { auth, db, rtdb } from '../firebase';
import { ref, set, update, onValue } from 'firebase/database';
import { 
  Pill, 
  Clock, 
  User as UserIcon, 
  LogOut, 
  Plus, 
  Settings, 
  History, 
  Activity,
  Bell,
  CheckCircle2,
  AlertCircle,
  Calendar,
  ChevronRight,
  Trash2,
  Edit2,
  Zap,
  Info,
  Copy,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, calculateMedicineTime, formatTime } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { Medicine, Patient, MealTimes, Log, DeviceStatus } from '../types';
import MedicineForm from './MedicineForm';
import MealTimeForm from './MealTimeForm';
import PatientProfile from './PatientProfile';
import Logs from './Logs';
import DeviceStatusComp from './DeviceStatus';

export default function Dashboard({ user }: { user: User }) {
  const [activeTab, setActiveTab] = useState<'overview' | 'medicines' | 'history' | 'calendar' | 'settings'>('overview');
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [mealTimes, setMealTimes] = useState<MealTimes | null>(null);
  const [logs, setLogs] = useState<Log[]>([]);
  const [deviceStatus, setDeviceStatus] = useState<DeviceStatus | null>(null);
  const [isMedicineModalOpen, setIsMedicineModalOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [isMealTimeModalOpen, setIsMealTimeModalOpen] = useState(false);

  useEffect(() => {
    if (!user) return;

    // Listen to medicines
    const qMed = query(collection(db, 'medicines'), where('caregiverUid', '==', user.uid));
    const unsubMed = onSnapshot(qMed, (snapshot) => {
      setMedicines(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Medicine)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'medicines');
    });

    // Listen to patient
    const unsubPatient = onSnapshot(doc(db, 'patient', user.uid), (doc) => {
      if (doc.exists()) setPatient(doc.data() as Patient);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `patient/${user.uid}`);
    });

    // Listen to meal times
    const unsubMeal = onSnapshot(doc(db, 'meal_times', user.uid), (doc) => {
      if (doc.exists()) setMealTimes(doc.data() as MealTimes);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `meal_times/${user.uid}`);
    });

    // Listen to logs
    const qLog = query(
      collection(db, 'logs'), 
      where('caregiverUid', '==', user.uid),
      orderBy('timestamp', 'desc')
    );
    const unsubLog = onSnapshot(qLog, (snapshot) => {
      setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Log)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'logs');
    });

    // Listen to device status from Realtime Database
    const rtdbStatusRef = ref(rtdb, `devices/${user.uid}/lastSeen`);
    const unsubDevice = onValue(rtdbStatusRef, (snapshot) => {
      if (snapshot.exists()) {
        setDeviceStatus({
          lastSeen: snapshot.val(),
          isOnline: true // The component calculates actual online status based on time
        } as DeviceStatus);
      }
    });

    return () => {
      unsubMed();
      unsubPatient();
      unsubMeal();
      unsubLog();
      unsubDevice();
    };
  }, [user]);

  // Sync to Realtime Database for ESP32 "Fast Lane"
  useEffect(() => {
    if (!user || !mealTimes) return;

    const syncToRTDB = async () => {
      try {
        const rtdbRef = ref(rtdb, `devices/${user.uid}`);
        await set(rtdbRef, {
          mealTimes: {
            breakfast: mealTimes.breakfast,
            lunch: mealTimes.lunch,
            dinner: mealTimes.dinner
          },
          medicines: medicines.reduce((acc, med) => {
            acc[med.id] = {
              name: med.name,
              slot: med.slot,
              food_instruction: med.food_instruction,
              status: med.status
            };
            return acc;
          }, {} as any),
          lastUpdated: new Date().toISOString()
        });
      } catch (error) {
        console.error('RTDB Sync Error:', error);
      }
    };

    syncToRTDB();
  }, [user, medicines, mealTimes]);

  const handleLogout = () => signOut(auth);

  const syncSchedule = async () => {
    if (!mealTimes || !user) {
      alert('Please set meal times first.');
      return;
    }
    
    try {
      const updates = medicines.map(med => {
        const mealTime = mealTimes[med.slot as keyof MealTimes] as string;
        if (!mealTime) return Promise.resolve();
        const newTime = calculateMedicineTime(mealTime, med.food_instruction);
        return updateDoc(doc(db, 'medicines', med.id!), { 
          calculatedTime: newTime,
          status: 'active'
        });
      });

      await Promise.all(updates);
      
      // Update RTDB for ESP32
      const rtdbRef = ref(rtdb, `devices/${user.uid}`);
      await update(rtdbRef, {
        lastUpdated: new Date().toISOString()
      });

      alert('All medicine times have been recalculated with the 2-minute offset logic!');
    } catch (error) {
      console.error('Error syncing schedule:', error);
      alert('Failed to sync schedule. Please try again.');
    }
  };

  // Helper to get the correct display time (always uses 2m offset logic)
  const getDisplayTime = (med: Medicine) => {
    if (!mealTimes) return med.calculatedTime || '--:--';
    const mealTime = mealTimes[med.slot as keyof MealTimes];
    if (!mealTime) return med.calculatedTime || '--:--';
    return calculateMedicineTime(mealTime, med.food_instruction);
  };

  const nextDose = medicines.length > 0 ? (() => {
    const today = new Date().toDateString();
    // Include both active and pending medicines for visibility, but prioritize active
    const relevantMedicines = medicines.map(m => ({
      ...m,
      displayTime: getDisplayTime(m)
    })).filter(m => {
      if (m.displayTime === '--:--') return false;
      
      // Check if this specific medicine was already taken TODAY
      const isTakenToday = logs.some(l => 
        l.slot === m.slot && 
        l.instruction === m.food_instruction && 
        l.status === 'taken' && 
        new Date(l.timestamp).toDateString() === today
      );
      
      return !isTakenToday;
    });
    
    if (relevantMedicines.length === 0) return null;
    
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    
    const getMinutes = (timeStr: string) => {
      if (!timeStr) return 0;
      // Handle potential narrow non-breaking space or other whitespace
      const normalized = timeStr.replace(/\s+/g, ' ').trim();
      
      // Handle 24h format if period is missing
      const [timePart, period] = normalized.split(' ');
      const [hours, minutes] = timePart.split(':').map(Number);
      let totalMinutes = hours * 60 + minutes;
      
      if (period) {
        if (period.toUpperCase() === 'PM' && hours !== 12) totalMinutes += 12 * 60;
        if (period.toUpperCase() === 'AM' && hours === 12) totalMinutes -= 12 * 60;
      }
      return totalMinutes;
    };

    const sortedMedicines = [...relevantMedicines].sort((a, b) => {
      return getMinutes(a.displayTime!) - getMinutes(b.displayTime!);
    });

    const nextToday = sortedMedicines.find(m => getMinutes(m.displayTime!) > currentMinutes);

    return nextToday || sortedMedicines[0];
  })() : null;

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      {/* Sidebar */}
      <aside className="w-full md:w-72 bg-white border-r border-slate-200 p-6 flex flex-col shrink-0">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-100">
            <Pill className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight">SmartMed</span>
        </div>

        <nav className="space-y-2 flex-1">
          <SidebarLink 
            active={activeTab === 'overview'} 
            onClick={() => setActiveTab('overview')} 
            icon={<Activity className="w-5 h-5" />} 
            label="Dashboard" 
          />
          <SidebarLink 
            active={activeTab === 'medicines'} 
            onClick={() => setActiveTab('medicines')} 
            icon={<Pill className="w-5 h-5" />} 
            label="Medicines" 
          />
          <SidebarLink 
            active={activeTab === 'history'} 
            onClick={() => setActiveTab('history')} 
            icon={<History className="w-5 h-5" />} 
            label="History Logs" 
          />
          <SidebarLink 
            active={activeTab === 'calendar'} 
            onClick={() => setActiveTab('calendar')} 
            icon={<Calendar className="w-5 h-5" />} 
            label="Calendar" 
          />
          <SidebarLink 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
            icon={<Settings className="w-5 h-5" />} 
            label="System Settings" 
          />
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-100">
          <div className="flex items-center gap-3 mb-6 p-2 rounded-xl bg-slate-50">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">
              {user.displayName?.[0] || user.email?.[0].toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold truncate">{user.displayName || 'Caregiver'}</p>
              <p className="text-xs text-slate-500 truncate">{user.email}</p>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(user.uid);
                  alert('Caregiver UID copied to clipboard!');
                }}
                className="text-[10px] text-blue-600 hover:underline flex items-center gap-1 mt-0.5"
              >
                <Copy className="w-2.5 h-2.5" />
                Copy UID
              </button>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all font-medium"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-slate-50/50 p-4 md:p-8">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">
              {activeTab === 'overview' && 'Health Overview'}
              {activeTab === 'medicines' && 'Medicine Schedule'}
              {activeTab === 'history' && 'Intake History'}
              {activeTab === 'calendar' && 'Medication Calendar'}
              {activeTab === 'settings' && 'System Configuration'}
            </h2>
            <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
              <p className="text-slate-500">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <DeviceStatusComp status={deviceStatus} />
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div 
              key="overview"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Top Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <PatientProfile 
                  patient={patient} 
                  onEdit={() => setIsPatientModalOpen(true)} 
                />
                
                <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Next Dose Card */}
                  <div className="bg-blue-600 rounded-3xl p-6 text-white shadow-xl shadow-blue-200 flex flex-col justify-between relative overflow-hidden">
                    <div className="absolute -right-4 -top-4 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
                    <div className="relative">
                      <div className="flex items-center gap-2 mb-4">
                        <Bell className="w-5 h-5 text-blue-200" />
                        <span className="text-blue-100 font-medium uppercase tracking-wider text-xs">Upcoming Reminder</span>
                      </div>
                      {nextDose ? (
                        <>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="text-3xl font-bold">{nextDose.name}</h3>
                            {nextDose.status === 'pending' && (
                              <span className="bg-amber-400/20 text-amber-200 text-[10px] px-2 py-0.5 rounded-full border border-amber-400/30 font-bold uppercase">Pending</span>
                            )}
                          </div>
                          <p className="text-blue-100 text-lg">{nextDose.dosage} • {nextDose.food_instruction === 'before' ? 'Before Food' : 'After Food'}</p>
                        </>
                      ) : (
                        <p className="text-blue-100">No upcoming doses scheduled</p>
                      )}
                    </div>
                    <div className="mt-8 flex items-center justify-between relative">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                          <Clock className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-xs text-blue-200 font-medium">Scheduled for</p>
                          <p className="text-xl font-bold">{nextDose?.calculatedTime || '--:--'}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-6 h-6 text-blue-300" />
                    </div>
                  </div>

                  {/* Meal Times Summary */}
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="font-bold text-slate-900">Meal Schedule</h3>
                      <button 
                        onClick={() => setIsMealTimeModalOpen(true)}
                        className="p-2 hover:bg-slate-50 rounded-lg text-blue-600 transition-all"
                      >
                        <Settings className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="space-y-4">
                      <MealTimeRow label="Breakfast" time={mealTimes?.breakfast} icon="🌅" />
                      <MealTimeRow label="Lunch" time={mealTimes?.lunch} icon="☀️" />
                      <MealTimeRow label="Dinner" time={mealTimes?.dinner} icon="🌙" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Real-time Monitoring */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-slate-900">Daily Monitoring</h3>
                  <div className="flex gap-2">
                    <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Taken
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-medium text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100">
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Pending
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-medium text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-100">
                      <div className="w-1.5 h-1.5 rounded-full bg-rose-500" /> Missed
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <SlotMonitoringCard 
                    slot="Breakfast" 
                    box="Medicine Box LED (Pin 26)"
                    medicines={medicines.filter(m => m.slot === 'breakfast').map(m => ({ ...m, calculatedTime: getDisplayTime(m) }))}
                    logs={logs.filter(l => l.slot === 'breakfast' && isSameDay(new Date(l.timestamp), new Date()))}
                  />
                  <SlotMonitoringCard 
                    slot="Lunch" 
                    box="Medicine Box LED (Pin 26)"
                    medicines={medicines.filter(m => m.slot === 'lunch').map(m => ({ ...m, calculatedTime: getDisplayTime(m) }))}
                    logs={logs.filter(l => l.slot === 'lunch' && isSameDay(new Date(l.timestamp), new Date()))}
                  />
                  <SlotMonitoringCard 
                    slot="Dinner" 
                    box="Medicine Box LED (Pin 26)"
                    medicines={medicines.filter(m => m.slot === 'dinner').map(m => ({ ...m, calculatedTime: getDisplayTime(m) }))}
                    logs={logs.filter(l => l.slot === 'dinner' && isSameDay(new Date(l.timestamp), new Date()))}
                  />
                </div>
              </section>
            </motion.div>
          )}

          {activeTab === 'medicines' && (
            <motion.div 
              key="medicines"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <button 
                  onClick={syncSchedule}
                  className="flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 px-6 py-3 rounded-xl font-bold transition-all shadow-sm"
                >
                  <Zap className="w-5 h-5 text-amber-500" />
                  Sync All Times (5m Offset)
                </button>
                <button 
                  onClick={() => setIsMedicineModalOpen(true)}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-blue-100 transition-all"
                >
                  <Plus className="w-5 h-5" />
                  Add Medicine
                </button>
              </div>

              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Medicine</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Dosage</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Time Slot</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Instruction</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Trigger Time</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {medicines.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                          No medicines scheduled yet.
                        </td>
                      </tr>
                    ) : (
                      medicines.map((med) => (
                        <tr key={med.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-bold text-slate-900">{med.name}</td>
                          <td className="px-6 py-4 text-slate-600">{med.dosage}</td>
                          <td className="px-6 py-4">
                            <span className={cn(
                              "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                              med.slot === 'breakfast' ? "bg-amber-50 text-amber-600 border border-amber-100" :
                              med.slot === 'lunch' ? "bg-blue-50 text-blue-600 border border-blue-100" :
                              "bg-indigo-50 text-indigo-600 border border-indigo-100"
                            )}>
                              {med.slot}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm font-medium text-slate-600">
                              {med.food_instruction === 'before' ? 'Before Food' : 'After Food'}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-mono font-bold text-blue-600">{getDisplayTime(med)}</td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex justify-end gap-2">
                              <button 
                                onClick={() => {
                                  setEditingMedicine(med);
                                  setIsMedicineModalOpen(true);
                                }}
                                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                                title="Edit Medicine"
                              >
                                <Edit2 className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={async () => {
                                  await deleteDoc(doc(db, 'medicines', med.id!));
                                }}
                                className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                                title="Remove Medicine"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div 
              key="history"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <Logs 
                logs={logs} 
                medicines={medicines}
                patient={patient}
              />
            </motion.div>
          )}

          {activeTab === 'calendar' && (
            <motion.div 
              key="calendar"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <CalendarView logs={logs} medicines={medicines} mealTimes={mealTimes} />
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-2xl mx-auto space-y-8"
            >
              <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                  <Clock className="w-6 h-6 text-blue-600" />
                  Meal Time Configuration
                </h3>
                <MealTimeForm 
                  mealTimes={mealTimes} 
                  onSave={async (times) => {
                    try {
                      // Check which slots changed
                      const changedSlots: string[] = [];
                      if (times.breakfast !== mealTimes?.breakfast) changedSlots.push('breakfast');
                      if (times.lunch !== mealTimes?.lunch) changedSlots.push('lunch');
                      if (times.dinner !== mealTimes?.dinner) changedSlots.push('dinner');

                      await setDoc(doc(db, 'meal_times', user.uid), { ...times, caregiverUid: user.uid });
                      
                      // Auto-update all medicines linked to these slots
                      const updates = medicines.map(med => {
                        const newMealTime = times[med.slot as keyof MealTimes] as string;
                        if (!newMealTime) return Promise.resolve();
                        
                        const newTime = calculateMedicineTime(newMealTime, med.food_instruction);
                        return updateDoc(doc(db, 'medicines', med.id!), { 
                          calculatedTime: newTime,
                          status: 'active'
                        });
                      });

                      await Promise.all(updates);

                      // Reset logs for changed slots for the current day
                      if (changedSlots.length > 0) {
                        const today = new Date();
                        const logsToDelete = logs.filter(l => 
                          changedSlots.includes(l.slot) && 
                          isSameDay(new Date(l.timestamp), today)
                        );
                        
                        const deletePromises = logsToDelete.map(l => deleteDoc(doc(db, 'logs', l.id!)));
                        await Promise.all(deletePromises);
                      }
                      
                      // Set sync flag for ESP32
                      await updateDoc(doc(db, 'device_status', user.uid), { sync: true });
                      
                      alert('Meal times updated, medicine schedule recalculated, and today\'s history for changed slots reset!');
                    } catch (error) {
                      console.error('Error updating meal times:', error);
                      alert('Failed to update meal times.');
                    }
                  }} 
                />
              </div>

              <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                  <Pill className="w-6 h-6 text-blue-600" />
                  Sync Status
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <div>
                      <p className="font-bold">Schedule Sync</p>
                      <p className="text-sm text-slate-500">Manually push all medicine times to device</p>
                    </div>
                    <button 
                      onClick={syncSchedule}
                      className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md shadow-blue-100 transition-all"
                    >
                      Sync Now
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {isMedicineModalOpen && (
          <MedicineForm 
            onClose={() => {
              setIsMedicineModalOpen(false);
              setEditingMedicine(null);
            }} 
            mealTimes={mealTimes}
            caregiverUid={user.uid}
            editingMedicine={editingMedicine}
          />
        )}
        {isPatientModalOpen && (
          <PatientProfileModal 
            patient={patient}
            onClose={() => setIsPatientModalOpen(false)}
            caregiverUid={user.uid}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function SidebarLink({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all",
        active 
          ? "bg-blue-50 text-blue-600 shadow-sm shadow-blue-100/50" 
          : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function MealTimeRow({ label, time, icon }: { label: string, time?: string, icon: string }) {
  return (
    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100">
      <div className="flex items-center gap-3">
        <span className="text-xl">{icon}</span>
        <span className="text-sm font-bold text-slate-700">{label}</span>
      </div>
      <span className="font-mono font-bold text-blue-600">{time ? formatTime(time) : '--:--'}</span>
    </div>
  );
}

function SlotMonitoringCard({ slot, box, medicines, logs }: { slot: string, box: string, medicines: Medicine[], logs: Log[] }) {
  const hasPendingMealTime = medicines.some(m => m.status === 'pending');
  
  // Helper to check if a specific medicine instruction was taken
  const isMedTaken = (instruction: string) => {
    return logs.some(l => l.instruction === instruction && l.status === 'taken');
  };

  // A slot is considered "taken" only if ALL scheduled instructions are taken
  const scheduledInstructions = Array.from(new Set(medicines.map(m => m.food_instruction)));
  const isTaken = scheduledInstructions.length > 0 && scheduledInstructions.every(inst => isMedTaken(inst));

  // A slot is "missed" if any scheduled medicine is past its time AND not taken
  const isMissed = !isTaken && medicines.length > 0 && medicines.some(m => {
    if (isMedTaken(m.food_instruction)) return false;
    
    if (!m.calculatedTime || m.calculatedTime === '--:--') return false;
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    
    const normalized = m.calculatedTime.replace(/\s+/g, ' ').trim();
    const [timePart, period] = normalized.split(' ');
    const [hours, minutes] = timePart.split(':').map(Number);
    let totalMinutes = hours * 60 + minutes;
    if (period) {
      if (period.toUpperCase() === 'PM' && hours !== 12) totalMinutes += 12 * 60;
      if (period.toUpperCase() === 'AM' && hours === 12) totalMinutes -= 12 * 60;
    }
    
    // Add a 1-minute grace period to prevent flickering
    return currentMinutes > (totalMinutes + 1);
  });

  const isPending = !isTaken && !isMissed;
  
  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="font-bold text-slate-900 text-lg">{slot} Slot</h4>
          <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">{box}</p>
        </div>
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center",
          isTaken ? "bg-emerald-50 text-emerald-600" : 
          isMissed ? "bg-rose-50 text-rose-600" : 
          "bg-amber-50 text-amber-600"
        )}>
          {isTaken ? <CheckCircle2 className="w-6 h-6" /> : 
           isMissed ? <AlertCircle className="w-6 h-6" /> : 
           <Clock className="w-6 h-6" />}
        </div>
      </div>

      <div className="flex-1 space-y-3 mb-6">
        {medicines.length === 0 ? (
          <p className="text-sm text-slate-400 italic">No medicines scheduled</p>
        ) : (
          medicines.map(m => {
            const taken = isMedTaken(m.food_instruction);
            return (
              <div key={m.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50/50">
                <div className="flex items-center gap-2">
                  {taken ? <CheckCircle2 className="w-3 h-3 text-emerald-500" /> : <Clock className="w-3 h-3 text-slate-300" />}
                  <div>
                    <p className="text-sm font-bold text-slate-800">{m.name}</p>
                    <p className="text-xs text-slate-500">{m.food_instruction === 'before' ? 'Before' : 'After'} Food</p>
                  </div>
                </div>
                <p className="text-xs font-mono font-bold text-blue-600">{m.calculatedTime || '--:--'}</p>
              </div>
            );
          })
        )}
      </div>

      <div className="pt-4 border-t border-slate-100">
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Status</p>
        {medicines.length === 0 ? (
          <div className="flex items-center gap-2 text-slate-400 font-bold text-sm">
            <Info className="w-4 h-4" />
            No Medication Added
          </div>
        ) : hasPendingMealTime ? (
          <div className="flex items-center gap-2 text-amber-600 font-bold text-sm">
            <AlertCircle className="w-4 h-4" />
            Pending (Meal time not set)
          </div>
        ) : isTaken ? (
          <div className="flex items-center gap-2 text-emerald-600 font-bold text-sm">
            <CheckCircle2 className="w-4 h-4" />
            All Doses Taken
          </div>
        ) : isMissed ? (
          <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
            <AlertCircle className="w-4 h-4" />
            Missed
          </div>
        ) : (
          <div className="flex items-center gap-2 text-amber-600 font-bold text-sm">
            <Clock className="w-4 h-4" />
            Pending
          </div>
        )}
      </div>
    </div>
  );
}

function PatientProfileModal({ patient, onClose, caregiverUid }: { patient: Patient | null, onClose: () => void, caregiverUid: string }) {
  const [formData, setFormData] = useState<Patient>(patient || {
    name: '',
    age: 0,
    medicalConditions: '',
    caregiverUid
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await setDoc(doc(db, 'patient', caregiverUid), formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden"
      >
        <div className="p-8">
          <h3 className="text-2xl font-bold mb-6">Patient Profile</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Name</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Age</label>
                <input 
                  type="number" 
                  value={formData.age}
                  onChange={e => setFormData({...formData, age: parseInt(e.target.value)})}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Medical Conditions</label>
              <textarea 
                value={formData.medicalConditions}
                onChange={e => setFormData({...formData, medicalConditions: e.target.value})}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 h-24 resize-none"
              />
            </div>
            <div className="flex gap-3 pt-4">
              <button 
                type="button"
                onClick={onClose}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-100 transition-all"
              >
                Save Profile
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}

function CalendarView({ logs, medicines, mealTimes }: { logs: Log[], medicines: Medicine[], mealTimes: MealTimes | null }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const getDisplayTime = (med: Medicine) => {
    if (!mealTimes) return med.calculatedTime || '--:--';
    const mealTime = mealTimes[med.slot as keyof MealTimes];
    if (!mealTime) return med.calculatedTime || '--:--';
    return calculateMedicineTime(mealTime, med.food_instruction);
  };

  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(currentMonth)),
    end: endOfWeek(endOfMonth(currentMonth)),
  });

  const getDayStatus = (day: Date) => {
    if (isAfter(startOfDay(day), startOfDay(new Date()))) return 'future';
    
    const dayLogs = logs.filter(l => isSameDay(new Date(l.timestamp), day));
    const dayMedicines = medicines; // Assuming medicines are daily for now

    if (dayMedicines.length === 0) return 'none';

    const slots = ['breakfast', 'lunch', 'dinner'];
    const activeSlots = slots.filter(s => dayMedicines.some(m => m.slot === s));
    
    if (activeSlots.length === 0) return 'none';

    const takenSlots = activeSlots.filter(s => {
      const medsForSlot = dayMedicines.filter(m => m.slot === s);
      const instructions = Array.from(new Set(medsForSlot.map(m => m.food_instruction)));
      return instructions.every(inst => dayLogs.some(l => l.slot === s && l.instruction === inst && l.status === 'taken'));
    });
    
    if (takenSlots.length === activeSlots.length) return 'complete';

    if (isAfter(startOfDay(day), startOfDay(new Date()))) return 'future';

    if (isToday(day)) {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      
      const hasMissed = activeSlots.some(s => {
        const medsForSlot = dayMedicines.filter(m => m.slot === s);
        return medsForSlot.some(m => {
          const isTaken = dayLogs.some(l => l.slot === s && l.instruction === m.food_instruction && l.status === 'taken');
          if (isTaken) return false;
          
          const displayTime = getDisplayTime(m);
          if (displayTime === '--:--') return false;
          const normalized = displayTime.replace(/\s+/g, ' ').trim();
          const [timePart, period] = normalized.split(' ');
          const [hours, minutes] = timePart.split(':').map(Number);
          let totalMinutes = hours * 60 + minutes;
          if (period) {
            if (period.toUpperCase() === 'PM' && hours !== 12) totalMinutes += 12 * 60;
            if (period.toUpperCase() === 'AM' && hours === 12) totalMinutes -= 12 * 60;
          }
          return currentMinutes > totalMinutes;
        });
      });

      if (hasMissed) return 'missed';
      return 'partial';
    }

    return 'missed';
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <h3 className="text-xl font-bold text-slate-900">{format(currentMonth, 'MMMM yyyy')}</h3>
        <div className="flex gap-2">
          <button 
            onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
            className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-all border border-slate-200"
          >
            <ChevronRight className="w-5 h-5 rotate-180" />
          </button>
          <button 
            onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
            className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-all border border-slate-200"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 bg-slate-50 border-b border-slate-100">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="py-3 text-center text-xs font-bold text-slate-400 uppercase tracking-wider">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {days.map((day, i) => {
          const status = getDayStatus(day);
          const isCurrentMonth = isSameMonth(day, currentMonth);
          
          return (
            <div 
              key={day.toString()} 
              className={cn(
                "min-h-[100px] p-2 border-r border-b border-slate-100 transition-all",
                !isCurrentMonth && "bg-slate-50/50 opacity-40",
                i % 7 === 6 && "border-r-0"
              )}
            >
              <div className="flex justify-between items-start mb-2">
                <span className={cn(
                  "text-sm font-bold w-7 h-7 flex items-center justify-center rounded-full",
                  isToday(day) ? "bg-blue-600 text-white" : "text-slate-600"
                )}>
                  {format(day, 'd')}
                </span>
                
                {status === 'complete' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                {status === 'missed' && <AlertCircle className="w-4 h-4 text-rose-500" />}
                {status === 'partial' && <Clock className="w-4 h-4 text-amber-500" />}
              </div>

              <div className="space-y-1">
                {status !== 'future' && status !== 'none' && (
                  <div className="flex flex-wrap gap-1">
                    {['breakfast', 'lunch', 'dinner'].map(s => {
                      const hasMed = medicines.some(m => m.slot === s);
                      if (!hasMed) return null;
                      const taken = logs.some(l => isSameDay(new Date(l.timestamp), day) && l.slot === s && l.status === 'taken');
                      return (
                        <div 
                          key={s} 
                          title={s.charAt(0).toUpperCase() + s.slice(1)}
                          className={cn(
                            "w-2 h-2 rounded-full",
                            taken ? "bg-emerald-500" : "bg-slate-200"
                          )} 
                        />
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-6">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <div className="w-3 h-3 rounded-full bg-emerald-500" /> All Taken
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <div className="w-3 h-3 rounded-full bg-rose-500" /> Missed Some
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <div className="w-3 h-3 rounded-full bg-amber-500" /> In Progress
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <div className="w-3 h-3 rounded-full bg-slate-200" /> No Medicine
        </div>
      </div>
    </div>
  );
}
