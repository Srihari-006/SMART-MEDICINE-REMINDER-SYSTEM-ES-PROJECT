import React, { useState } from 'react';
import { MealTimes } from '../types';

export default function MealTimeForm({ mealTimes, onSave }: { mealTimes: MealTimes | null, onSave: (times: Partial<MealTimes>) => void }) {
  const [formData, setFormData] = useState<Partial<MealTimes>>(mealTimes || {
    breakfast: '08:00',
    lunch: '13:00',
    dinner: '20:00'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 uppercase">Breakfast Time</label>
          <input 
            type="time" 
            value={formData.breakfast}
            onChange={e => setFormData({...formData, breakfast: e.target.value})}
            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-mono font-bold"
            required
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 uppercase">Lunch Time</label>
          <input 
            type="time" 
            value={formData.lunch}
            onChange={e => setFormData({...formData, lunch: e.target.value})}
            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-mono font-bold"
            required
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 uppercase">Dinner Time</label>
          <input 
            type="time" 
            value={formData.dinner}
            onChange={e => setFormData({...formData, dinner: e.target.value})}
            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 font-mono font-bold"
            required
          />
        </div>
      </div>
      <button 
        type="submit"
        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-100 transition-all"
      >
        Update Meal Times
      </button>
    </form>
  );
}
