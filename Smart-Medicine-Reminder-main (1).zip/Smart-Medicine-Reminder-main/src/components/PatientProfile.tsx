import { Patient } from '../types';
import { User as UserIcon, Edit2, Phone, Activity } from 'lucide-react';

export default function PatientProfile({ patient, onEdit }: { patient: Patient | null, onEdit: () => void }) {
  if (!patient) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-col items-center justify-center text-center">
        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mb-4">
          <UserIcon className="w-8 h-8" />
        </div>
        <h3 className="font-bold text-slate-900 mb-2">No Patient Profile</h3>
        <p className="text-sm text-slate-500 mb-6">Set up your patient's profile to start managing their health.</p>
        <button 
          onClick={onEdit}
          className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-100 transition-all"
        >
          Create Profile
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm relative overflow-hidden">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
            <UserIcon className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900">{patient.name}</h3>
            <p className="text-sm text-slate-500">{patient.age} years old</p>
          </div>
        </div>
        <button 
          onClick={onEdit}
          className="p-2 hover:bg-slate-50 rounded-lg text-slate-400 hover:text-blue-600 transition-all"
        >
          <Edit2 className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-4">
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
          <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
            <Activity className="w-3.5 h-3.5" />
            Medical Conditions
          </div>
          <p className="text-sm text-slate-700 font-medium leading-relaxed">
            {patient.medicalConditions || 'No conditions listed'}
          </p>
        </div>
      </div>
    </div>
  );
}
