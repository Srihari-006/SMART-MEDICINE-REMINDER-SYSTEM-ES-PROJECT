import { DeviceStatus } from '../types';
import { Wifi, WifiOff, Clock } from 'lucide-react';
import { cn } from '../lib/utils';
import { useState, useEffect } from 'react';

export default function DeviceStatusComp({ status }: { status: DeviceStatus | null }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 5000);
    return () => clearInterval(timer);
  }, []);

  if (!status) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 text-slate-500 rounded-full text-xs font-bold border border-slate-200">
        <WifiOff className="w-3.5 h-3.5" />
        No Device Linked
      </div>
    );
  }

  const lastSeenTime = new Date(status.lastSeen).getTime();
  const secondsAgo = Math.floor((now.getTime() - lastSeenTime) / 1000);
  const isOnline = status.isOnline && secondsAgo < 45; // 45s buffer for 10s sync

  return (
    <div className="flex items-center gap-4">
      <div className={cn(
        "flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border transition-all",
        isOnline 
          ? "bg-emerald-50 text-emerald-600 border-emerald-100 shadow-sm shadow-emerald-100/50" 
          : "bg-rose-50 text-rose-600 border-rose-100 shadow-sm shadow-rose-100/50"
      )}>
        <div className={cn(
          "w-1.5 h-1.5 rounded-full animate-pulse",
          isOnline ? "bg-emerald-500" : "bg-rose-500"
        )} />
        {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
        ESP32 {isOnline ? 'Online' : 'Offline'}
      </div>
      
      <div className="hidden md:flex flex-col text-right">
        <div className="flex items-center gap-1.5 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
          <Clock className="w-3 h-3" />
          Last Sync
        </div>
        <p className="text-xs font-medium text-slate-400">
          {secondsAgo < 5 ? 'Just now' : `${secondsAgo}s ago`}
        </p>
      </div>
    </div>
  );
}
