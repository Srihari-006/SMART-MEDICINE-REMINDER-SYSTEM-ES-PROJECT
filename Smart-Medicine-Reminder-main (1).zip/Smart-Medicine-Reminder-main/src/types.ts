export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
}

export interface Patient {
  name: string;
  age: number;
  medicalConditions: string;
  caregiverUid: string;
}

export interface MealTimes {
  breakfast: string;
  lunch: string;
  dinner: string;
  caregiverUid: string;
}

export interface Medicine {
  id?: string;
  name: string;
  dosage: string;
  slot: 'breakfast' | 'lunch' | 'dinner';
  food_instruction: 'before' | 'after';
  notes?: string;
  calculatedTime?: string;
  status: 'active' | 'pending';
  caregiverUid: string;
}

export interface Log {
  id?: string;
  slot: string;
  instruction?: 'before' | 'after';
  status: 'taken' | 'missed';
  timestamp: string;
  medicineName?: string;
  caregiverUid: string;
}

export interface DeviceStatus {
  isOnline: boolean;
  lastSeen: string;
  sync: boolean;
  caregiverUid: string;
}
