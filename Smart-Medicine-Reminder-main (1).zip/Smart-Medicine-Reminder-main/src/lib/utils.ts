import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function calculateMedicineTime(mealTime: string, instruction: 'before' | 'after'): string {
  const [hours, minutes] = mealTime.split(':').map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);

  if (instruction === 'before') {
    date.setMinutes(date.getMinutes() - 2);
  } else {
    date.setMinutes(date.getMinutes() + 2);
  }

  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
}

export function formatTime(time: string): string {
  const [hours, minutes] = time.split(':').map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
}
