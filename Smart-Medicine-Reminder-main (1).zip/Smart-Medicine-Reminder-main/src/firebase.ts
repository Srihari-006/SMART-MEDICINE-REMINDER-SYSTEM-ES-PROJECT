import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { initializeFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getDatabase } from 'firebase/database';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

// Use initializeFirestore with long-polling to avoid "unavailable" errors in restricted environments
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
}, firebaseConfig.firestoreDatabaseId);

export const rtdb = getDatabase(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Connection Test
async function testConnection() {
  try {
    // Try to fetch a doc to test connectivity
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("✅ Firestore connection successful");
  } catch (error: any) {
    // If we get "insufficient permissions", it means we ARE connected to the server!
    if (error?.code === 'permission-denied') {
      console.log("✅ Firestore connection verified (Server reached)");
    } else if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("❌ Firestore connection failed: The client is offline. Please check your Firebase configuration.");
    } else {
      console.warn("⚠️ Firestore connection test note:", error.message || error);
    }
  }
}

testConnection();
